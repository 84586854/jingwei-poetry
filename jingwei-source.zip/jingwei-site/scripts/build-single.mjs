import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const out=path.join(root,'publish');
await fs.mkdir(out,{recursive:true});
let html=await fs.readFile(path.join(root,'index.html'),'utf8');
let css=await fs.readFile(path.join(root,'assets/styles.css'),'utf8');
const image=(await fs.readFile(path.join(root,'assets/river-landscape.webp'))).toString('base64');
css=css.replace("url('./river-landscape.webp')","url('data:image/webp;base64,"+image+"')");
html=html.replace('<link rel="stylesheet" href="./assets/styles.css">','<style>'+css+'</style>');
const icon=(await fs.readFile(path.join(root,'assets/favicon.svg'))).toString('base64');
html=html.replace('./assets/favicon.svg','data:image/svg+xml;base64,'+icon);
html=html.replace('  <script type="module" src="./assets/app.js"></script>','');
for(const [file,id]of [['source.xlsx','source'],['corpus.json','corpus'],['metadata.json','metadata']])html=html.replaceAll('href="./data/'+file+'"','href="#" data-embedded-file="'+id+'"');
let core=await fs.readFile(path.join(root,'assets/core.js'),'utf8');
core=core.replace(/^export /gm,'');
let app=await fs.readFile(path.join(root,'assets/app.js'),'utf8');
app=app.replace(/^import .*?;\n/,'');
app=app.replace("    const response=await fetch(new URL('../data/corpus.json',import.meta.url));if(!response.ok)throw new Error('数据读取失败（'+response.status+'）。');\n    prepared=prepare(await response.json());", "    prepared=prepare(JSON.parse(document.getElementById('embedded-corpus').textContent));");
if(app.includes('await fetch('))throw new Error('Unresolved data fetch');
const corpus=(await fs.readFile(path.join(root,'data/corpus.json'),'utf8')).replaceAll('<','\\u003c');
const metadata=(await fs.readFile(path.join(root,'data/metadata.json'),'utf8')).replaceAll('<','\\u003c');
const source=(await fs.readFile(path.join(root,'data/source.xlsx'))).toString('base64');
const setup=`
const embeddedPayloads={
  source:{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',name:'李白-杜甫.xlsx',bytes:Uint8Array.from(atob(document.getElementById('embedded-source').textContent.trim()),c=>c.charCodeAt(0))},
  corpus:{type:'application/json;charset=utf-8',name:'corpus.json',bytes:document.getElementById('embedded-corpus').textContent},
  metadata:{type:'application/json;charset=utf-8',name:'metadata.json',bytes:document.getElementById('embedded-metadata').textContent}
};
for(const [id,payload]of Object.entries(embeddedPayloads)){
  const href=URL.createObjectURL(new Blob([payload.bytes],{type:payload.type}));
  for(const link of document.querySelectorAll('[data-embedded-file="'+id+'"]')){link.href=href;if(link.hasAttribute('download'))link.download=payload.name;}
}
`;
html=html.replace('</body>','<script id="embedded-corpus" type="application/json">'+corpus+'</script>\n<script id="embedded-metadata" type="application/json">'+metadata+'</script>\n<script id="embedded-source" type="application/octet-stream">'+source+'</script>\n<script type="module">\n'+core+'\n'+setup+'\n'+app+'\n</script>\n</body>');
await fs.writeFile(path.join(out,'index.html'),html);
await fs.writeFile(path.join(out,'README.md'),`# 泾渭分明 · 才思相融\n\n[打开网站](https://84586854.github.io/jingwei-poetry/)\n\n以双河汇流为意象，探索李白与杜甫的全部 23,448 条原始诗句相似配对。包括卷首山水、双河观流、作品矩阵、原句对读、分布与门槛曲线、作品筛选、链接分享和 CSV 导出，适配手机与桌面。\n\n当前仓库中的 index.html 为完整发布版，图片、数据、样式与交互全部内置，不依赖外部服务。原始 Excel 可在网站卷后下载。\n\n[下载可编辑完整源码](./jingwei-source.zip)\n\n源码包包含分离的 HTML/CSS/JavaScript、原始 Excel、无损数据、数据导入器、测试、构建脚本和可选 GitHub Actions 工作流。构建单文件版本：node scripts/build-single.mjs。\n\n发布方式：GitHub Pages → Deploy from a branch → main / (root)。\n\n相似度仅描述收录诗句的文本联系，不是两部文集整体相似率，也不判定引用或影响。山水图为 AI 生成艺术意象；河面最多显示按排名均匀抽取的 72 条，完整配对在拾句中提供。\n`);
console.log('Created self-contained publishing version:',html.length,'characters');
