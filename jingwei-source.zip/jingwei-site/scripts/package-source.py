"""Package the editable source without recursively including generated bundles."""
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parent.parent
output = root.parent / '泾渭成章_完整网站源码.zip'
excluded = {'dist', 'publish', 'node_modules', '.git', '__pycache__'}
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(root.rglob('*')):
        relative = file.relative_to(root)
        if file.is_file() and not any(part in excluded for part in relative.parts):
            archive.write(file, Path('jingwei-site') / relative)
(root / 'publish').mkdir(exist_ok=True)
shutil.copy2(output, root / 'publish/jingwei-source.zip')
print(f'Packaged complete editable source: {output.name} ({output.stat().st_size:,} bytes)')
