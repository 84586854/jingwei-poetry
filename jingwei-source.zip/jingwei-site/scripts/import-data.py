"""Import the supplied workbook without third-party Python dependencies."""
import argparse
from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('source', type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parent.parent
ns = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(args.source) as archive:
    shared = [''.join(x.itertext()) for x in ET.fromstring(archive.read('xl/sharedStrings.xml')).findall('m:si', ns)]
    workbook = ET.fromstring(archive.read('xl/workbook.xml'))
    sheet = next(s for s in workbook.find('m:sheets', ns) if s.get('name') == '李白-杜甫')
    rels = {x.get('Id'): x.get('Target') for x in ET.fromstring(archive.read('xl/_rels/workbook.xml.rels'))}
    target = rels[sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')]
    sheet_path = target.lstrip('/') if target.startswith('/') else 'xl/' + target
    worksheet = ET.fromstring(archive.read(sheet_path))
poems, lines = [[], []], [[], []]
poem_index, line_index = [{}, {}], [{}, {}]
records, headers = [], {}
for row in worksheet.findall('m:sheetData/m:row', ns):
    row_number = int(row.get('r'))
    cells = {}
    for cell in row:
        value = cell.find('m:v', ns)
        raw = value.text if value is not None else ''
        if cell.get('t') == 's' and raw:
            raw = shared[int(raw)]
        elif cell.get('t') == 'inlineStr':
            raw = ''.join(cell.find('m:is', ns).itertext())
        cells[cell.get('r').rstrip('0123456789')] = raw
    if row_number == 1:
        headers = cells
        continue
    if not cells:
        continue
    if not all(cells.get(k) for k in 'ABCDEFG') or cells['A'] != '李白' or cells['D'] != '杜甫':
        raise ValueError(f'第 {row_number} 行缺少字段或作者不符')
    endpoints = []
    for side, title, text, poem_id, position in [(0,'B','C','H','I'), (1,'E','F','J','K')]:
        pk = (cells[poem_id], cells[title])
        if pk not in poem_index[side]:
            poem_index[side][pk] = len(poems[side])
            poems[side].append([cells[title], cells[poem_id]])
        pi = poem_index[side][pk]
        lk = (pi, cells[position], cells[text])
        if lk not in line_index[side]:
            line_index[side][lk] = len(lines[side])
            lines[side].append([pi, cells[text], cells[position]])
        endpoints.append(line_index[side][lk])
    score = int(cells['G'])
    if not 7000 <= score <= 10000:
        raise ValueError(f'第 {row_number} 行分数超出当前版本的范围')
    records.append([*endpoints, score, row_number])
data = {'poems': poems, 'lines': lines, 'records': records}
scores = sorted(r[2] for r in records)
mid = len(scores) // 2
median = scores[mid] if len(scores) % 2 else (scores[mid-1] + scores[mid]) / 2
metadata = {
    'source_file': '李白-杜甫.xlsx',
    'source_sheet': '李白-杜甫',
    'source_sha256': hashlib.sha256(args.source.read_bytes()).hexdigest(),
    'generated_on': datetime.date.today().isoformat(),
    'original_headers': headers,
    'record_count': len(records),
    'poem_counts_in_records': {'李白': len(poems[0]), '杜甫': len(poems[1])},
    'line_counts_in_records': {'李白': len(lines[0]), '杜甫': len(lines[1])},
    'raw_score_min': min(scores), 'raw_score_max': max(scores),
    'raw_score_median': median, 'display_divisor': 10000,
    'threshold_controls': {str(t): sum(s >= t for s in scores) for t in [7000,7500,8000,8500,9000,9500,10000]},
    'duplicate_endpoint_pairs': len(records) - len({tuple(r[:2]) for r in records}),
    'schema': {
        'poems': 'Two lists, side 0 Li Bai, side 1 Du Fu. Each entry: [title, original H or J value].',
        'lines': 'Two lists. Each entry: [poem index, verbatim line, original I or K value].',
        'records': '[Li Bai line index, Du Fu line index, raw G-column score, original 1-based worksheet row].'
    },
    'unknown': ['similarity_algorithm', 'prior_filtering_rule', 'all_possible_line_pairs', 'whole_poem_context', 'composition_dates'],
    'artwork': 'AI-generated metaphorical landscape. Not a geographic map or quantitative chart.'
}
(root / 'data').mkdir(exist_ok=True)
(root / 'data/corpus.json').write_text(json.dumps(data, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
(root / 'data/metadata.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'records':len(records),'poems':metadata['poem_counts_in_records'],'sha256':metadata['source_sha256']},ensure_ascii=False))
