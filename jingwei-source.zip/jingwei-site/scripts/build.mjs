import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const destination=path.join(root,'dist');
await fs.rm(destination,{recursive:true,force:true});
await fs.mkdir(destination,{recursive:true});
for(const item of ['index.html','404.html','.nojekyll','assets','data'])await fs.cp(path.join(root,item),path.join(destination,item),{recursive:true});
const html=await fs.readFile(path.join(destination,'index.html'),'utf8');
for(const match of html.matchAll(/(?:href|src)="(\.\/[^"#]+)"/g)){const target=match[1].split('?')[0];await fs.access(path.resolve(destination,target));}
const data=JSON.parse(await fs.readFile(path.join(destination,'data/corpus.json'),'utf8'));
if(data.records.length!==23448)throw new Error('发布数据不完整');
console.log('Built dist/: all local assets present; 23,448 records.');
