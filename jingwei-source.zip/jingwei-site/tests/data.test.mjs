import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {prepare,filterRecords,aggregateWorks,workPairs,histogram,retention,safeState,parseHash,stateHash,endpoint,csvFor,sampleRows} from '../assets/core.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const data=JSON.parse(fs.readFileSync(path.join(root,'data/corpus.json'),'utf8'));
const prepared=prepare(data);
test('source controls, exact rows and retained counts agree with workbook',()=>{
  assert.equal(data.records.length,23448);assert.equal(data.poems[0].length,1056);assert.equal(data.poems[1].length,1428);
  const controls=new Map([[7000,23448],[7500,4956],[8000,951],[8500,168],[9000,27],[9500,5],[10000,1]]);
  for(const[t,n]of controls)assert.equal(retention(data.records,t),n);
  assert.equal(prepared.byRow.get(23449)[2],7538);assert.equal(endpoint(data,prepared.byRow.get(23449),0).text,'黄河当中流。');
  assert.equal(endpoint(data,prepared.byRow.get(54),0).text,endpoint(data,prepared.byRow.get(54),1).text);
});
test('aggregations reconcile without losing or duplicating records',()=>{
  assert.equal(histogram(data.records).reduce((n,b)=>n+b.count,0),23448);
  for(const side of [0,1])assert.equal(aggregateWorks(data,data.records,side).reduce((n,p)=>n+p.count,0),23448);
  assert.equal([...workPairs(data,data.records).values()].reduce((n,p)=>n+p.count,0),23448);
  assert.equal(new Set(sampleRows(data.records,72).map(r=>r[3])).size,72);
});
test('threshold, keyword and both work selections intersect correctly',()=>{
  const target=prepared.byRow.get(3527),a=endpoint(data,target,0),b=endpoint(data,target,1);
  const s=safeState({threshold:9000,query:'故乡',lb:a.poemIndex,df:b.poemIndex},data);
  const results=filterRecords(prepared,s);assert.ok(results.some(r=>r[3]===3527));assert.ok(results.every(r=>r[2]>=9000));
  assert.equal(filterRecords(prepared,safeState({threshold:7000,query:'不存在的检索词'},data)).length,0);
  assert.equal(filterRecords(prepared,safeState({threshold:10000},data)).length,1);
});
test('deep links restore selections and reject unsupported filter values',()=>{
  const s=safeState({threshold:8904,query:'故乡 & 月',lb:3,df:6,row:3527,page:2,sort:'asc'},data);
  const parsed=parseHash(stateHash('verses',s));assert.equal(parsed.view,'verses');assert.deepEqual(safeState(parsed.state,data),s);
  const invalid=safeState({threshold:10,lb:999999,df:-1,query:42,sort:'evil',page:-3},data);assert.equal(invalid.threshold,8000);assert.equal(invalid.lb,null);assert.equal(invalid.query,'');assert.equal(invalid.page,0);
});
test('CSV keeps raw scores, original indices, rows, punctuation and line endings',()=>{
  const csv=csvFor(data,[prepared.byRow.get(2)]);assert.ok(csv.startsWith('\uFEFF'));assert.ok(csv.includes('"7057","0.7057","114","1","41003","7"'));assert.ok(csv.includes('日日醉如泥。'));assert.equal(csv.split('\r\n').length,2);
});
