# 泾渭分明 · 才思相融

以双河汇流为意象，探索李白与杜甫的诗句相似关系。主题为“交融的天才之思，滋养了历史长河旁的一草一木”。

## 网站内容

- **卷首**：山水长卷、数据范围与一组真实诗句。
- **观流**：双河交汇，筛选相似度、查找文字、点击配对对读。
- **寻脉**：按配对数或最高分排列作品，切换作品矩阵指标。
- **拾句**：完整分页、双方作品筛选、排序、原表索引、分享链接与 CSV 导出。
- **读数**：完整分数分布、门槛留存曲线、数据范围说明。
- **卷后**：叙事与数据各自的含义、来源、限制和下载。

全部 **23,448** 条原始配对保留在 `data/corpus.json`；原始 Excel 保留在 `data/source.xlsx`。页面上的 1,056 / 1,428 部作品是文件配对中出现的作品数，不代表两位诗人的文集全貌。相似度不解释为影响、模仿或整体文集相似率。

## 本地打开

安装 Node.js 22 或更新版本后，无需安装依赖：

```sh
npm run dev
```

打开终端显示的本地地址。不要直接双击 `index.html`，因为浏览器通常会禁止本地文件读取数据。

```sh
npm test
npm run build
```

构建产物在 `dist/`。站点无运行时第三方依赖、不请求外部字体、无后端、无追踪脚本。筛选偏好只保存在本浏览器，分享链接包含门槛、搜索词、作品筛选和所选行。

## 托管到 GitHub Pages

1. 把整个项目上传至自己的 GitHub 仓库，主分支命名为 `main`。
2. 打开仓库 **Settings → Pages → Build and deployment → Source**，选择 **GitHub Actions**。
3. 推送到 `main` 或手动运行 **Publish Jingwei to GitHub Pages**。
4. 等待工作流成功，从部署结果打开网站。

工作流已放在 `.github/workflows/pages.yml`。所有资源使用相对路径，页面使用 `#` 导航，兼容 `https://账号.github.io/仓库名/` 的项目子目录。无需修改站点根路径。

可参考 [GitHub Pages 官方工作流说明](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages)。GitHub Free 使用 Pages 时仓库需要公开；其他账号方案支持范围以 [GitHub 官方说明](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)为准。

## 重新导入原表

```sh
python3 scripts/import-data.py data/source.xlsx
npm test
npm run build
```

导入器仅使用 Python 标准库，生成紧凑数据与校验元信息。H / I / J / K 索引保持原始文本，不推断其未给出的历史含义。当前版本的完整性测试以本次原表为准；更换数据集时应同步核验统计范围和页面说明。

## 视觉与图像

暖纸底色、宋体标题、青绿与赭金区分作者。河流形态、山石与草木是艺术意象；河面最多展示按排名均匀抽取的 72 条记录。完整结果在“拾句”提供。

首页山水图保存在 `assets/river-landscape.webp`，由内置图像生成工具生成，随后转换为网页图片。生成说明见 [assets/ARTWORK.md](assets/ARTWORK.md)。该图为意象画，不是地理地图或数据图。

## 数据出处与计算

- 原表：`李白-杜甫.xlsx`，工作表 `李白-杜甫`。
- 范围：23,448 条记录，分数 7,000—10,000。
- 展示分数：按 G 列表头除以 10,000。
- 作品指标：达到门槛的原始配对数量、其中最高分。
- 未知：原算法、事先筛选方式、未收录句对、完整上下文、创作年代。
- 完整性与源文件 SHA-256：`data/metadata.json`。
