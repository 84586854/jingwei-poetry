// Photographic terrain stays still; only the water surface is advected and lit.
// This is an artistic water renderer, not a hydrodynamic model of the poetry.
export function riverChannel(y, side) {
  const t=Math.max(0,Math.min(1,y));
  const merge=.43;
  const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);};
  const f=Math.min(1,t/merge);
  const left=.13+.42*Math.pow(f,1.15);
  const right=.96-.41*Math.pow(f,.85);
  const downstream=.55+.10*smooth((t-merge)/.57)+.025*Math.sin((t-merge)*8);
  const blend=smooth((t-.38)/.10);
  return (side?right:left)*(1-blend)+downstream*blend;
}

const VERTEX=`
attribute vec2 position;
varying vec2 uv;
void main(){uv=position*.5+.5;gl_Position=vec4(position,0.,1.);}
`;
const FRAGMENT=`
precision highp float;
varying vec2 uv;
uniform sampler2D photograph;
uniform vec2 crop;
uniform float clock;
float hash(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x),mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x),f.y);}
float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<3;i++){v+=a*noise(p);p=p*2.03+vec2(13.7,7.1);a*=.5;}return v;}
float leftChannel(float y){float f=clamp(y/.43,0.,1.);return .13+.42*pow(f,1.15);}
float rightChannel(float y){float f=clamp(y/.43,0.,1.);return .96-.41*pow(f,.85);}
float mainChannel(float y){return .55+.10*smoothstep(.43,1.,y)+.025*sin((y-.43)*8.);}
float center(float y,float side){float c=mix(leftChannel(y),rightChannel(y),side);return mix(c,mainChannel(y),smoothstep(.38,.48,y));}
vec3 photo(vec2 p){return texture2D(photograph,clamp(p,.001,.999)).rgb;}
void main(){
  vec2 p=(vec2(uv.x,1.-uv.y)-.5)*crop+.5;
  vec3 original=photo(p);
  float l=center(p.y,0.),r=center(p.y,1.);
  float dl=abs(p.x-l),dr=abs(p.x-r);
  float width=mix(.075+.17*smoothstep(0.,.44,p.y),.25+.09*smoothstep(.4,1.,p.y),smoothstep(.35,.47,p.y));
  float channel=1.-smoothstep(width*.78,width,max(0.,min(dl,dr)));
  float vegetation=smoothstep(.015,.11,original.g-max(original.r,original.b));
  float riverColor=max(smoothstep(.01,.12,original.b-original.r),smoothstep(.0,.10,original.r-original.g));
  float water=channel*(1.-vegetation*.96)*(.32+.68*riverColor);
  float side=step(dr,dl);
  float slope=(center(p.y+.002,side)-center(p.y-.002,side))/.004;
  vec2 flow=normalize(vec2(slope,1.));
  vec2 across=vec2(flow.y,-flow.x);
  float crossCoord=dot(p,across);
  float alongCoord=dot(p,flow);
  vec2 surface=vec2(crossCoord*126.,alongCoord*61.-clock*1.15);
  float coarse=fbm(surface*.24+vec2(0.,clock*.12));
  float detail=fbm(surface+vec2(coarse*2.7,0.));
  float wave=sin(crossCoord*610.+alongCoord*96.-clock*5.1+coarse*9.);
  vec2 distortion=across*(detail-.46)*.0034+flow*wave*.0016;
  float phase=fract(clock*.065),phase2=fract(clock*.065+.5);
  float weight=abs(phase*2.-1.);
  vec3 moving=mix(photo(p-flow*phase*.026+distortion),photo(p-flow*phase2*.026+distortion),weight);
  vec3 color=mix(original,moving,water*.83);
  float ridges=pow(max(0.,wave*.5+.5),17.)*(.45+.55*detail);
  float sparks=pow(smoothstep(.50,.84,detail),7.);
  float rapids=exp(-pow((p.y-.43)*8.,2.))*exp(-pow((p.x-.525)*6.,2.));
  float foam=smoothstep(.70,.89,fbm(surface*.72+vec2(7.,clock*.43))+coarse*.22);
  color+=water*(ridges*.044+sparks*.075)*vec3(.88,.94,.88);
  color=mix(color,vec3(.88,.91,.83),water*foam*(.075+rapids*.12));
  color*=1.-water*(.025*coarse);
  gl_FragColor=vec4(color,1.);
}
`;

export function createRiverScene({waterCanvas,overlayCanvas,image,onPick,onHover,onState}) {
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const ctx=overlayCanvas.getContext('2d');
  let gl=null,program=null,texture=null,uniforms=null,ready=false;
  let active=false,paused=reduced.matches,showParticles=true,records=[],selectedRow=null;
  let width=1,height=1,crop=[1,1],hits=[],frame=0,lastFrame=0,elapsed=0,previousTime=0,failed=false;
  const resources=[];

  function report(){onState?.({paused,showParticles,ready,renderer:gl?'webgl':'photo'});}
  function compile(type,source){
    const shader=gl.createShader(type);gl.shaderSource(shader,source);gl.compileShader(shader);
    if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS)){const message=gl.getShaderInfoLog(shader);gl.deleteShader(shader);throw new Error(message);}
    resources.push(shader);return shader;
  }
  function initialize(){
    try{
      gl=waterCanvas.getContext('webgl',{alpha:false,antialias:false,powerPreference:'low-power',preserveDrawingBuffer:false});
      if(!gl){ready=true;report();requestFrame();return;}
      program=gl.createProgram();gl.attachShader(program,compile(gl.VERTEX_SHADER,VERTEX));gl.attachShader(program,compile(gl.FRAGMENT_SHADER,FRAGMENT));gl.linkProgram(program);
      if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(program));
      gl.useProgram(program);
      const buffer=gl.createBuffer();resources.push(buffer);gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),gl.STATIC_DRAW);
      const attribute=gl.getAttribLocation(program,'position');gl.enableVertexAttribArray(attribute);gl.vertexAttribPointer(attribute,2,gl.FLOAT,false,0,0);
      texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGB,gl.RGB,gl.UNSIGNED_BYTE,image);
      uniforms={crop:gl.getUniformLocation(program,'crop'),clock:gl.getUniformLocation(program,'clock')};
      ready=true;waterCanvas.classList.add('water-ready');resize();report();requestFrame();
    }catch(error){failed=true;gl=null;waterCanvas.classList.remove('water-ready');ready=true;report();requestFrame();console.warn('Water surface uses photographic fallback:',error.message);}
  }
  function resize(){
    const rect=overlayCanvas.getBoundingClientRect();if(rect.width<1)return;
    const dpr=Math.min(devicePixelRatio||1,1.5,1000/rect.width);
    width=rect.width;height=rect.height;
    const pw=Math.round(width*dpr),ph=Math.round(height*dpr);
    if(overlayCanvas.width!==pw||overlayCanvas.height!==ph){overlayCanvas.width=pw;overlayCanvas.height=ph;}
    ctx.setTransform(dpr,0,0,dpr,0,0);
    const imageRatio=(image.naturalWidth||4)/(image.naturalHeight||3),displayRatio=width/height;
    crop=imageRatio>displayRatio?[displayRatio/imageRatio,1]:[1,imageRatio/displayRatio];
    if(gl){
      if(waterCanvas.width!==pw||waterCanvas.height!==ph){waterCanvas.width=pw;waterCanvas.height=ph;}
      gl.viewport(0,0,pw,ph);
    }
    render();
  }
  function point(t,side,lane){
    const y=.02+t*.95;
    const channel=riverChannel(y,side);
    const wiggle=.004*Math.sin(y*24+lane*5);
    const merged=Math.max(0,Math.min(1,(y-.39)/.13));
    const x=channel+lane*.05+wiggle*(1-merged*.7);
    return {x:((x-.5)/crop[0]+.5)*width,y:((y-.5)/crop[1]+.5)*height};
  }
  function overlay(){
    ctx.clearRect(0,0,width,height);hits=[];
    if(!showParticles)return;
    for(const record of records){
      const seed=((record[3]*.61803398875)%1),phase=(seed+elapsed*.034)%1;
      const lane=((record[3]*.41421356237)%1)-.5;
      const a=point(phase,0,lane),b=point(phase,1,lane);
      const activeRecord=record[3]===selectedRow,q=(record[2]-7000)/3000;
      const merged=phase>.47;
      const pts=merged?[{x:(a.x+b.x)*.5,y:a.y}]:[a,b];
      for(let side=0;side<pts.length;side++){
        const p=pts[side];if(p.x<-10||p.x>width+10||p.y<-10||p.y>height+10)continue;
        const r=activeRecord?4.2:1.1+q*1.3,alpha=activeRecord?.95:.24+q*.44;
        const gradient=ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,r*4.5);
        gradient.addColorStop(0,'rgba(255,248,213,'+(alpha*.6)+')');gradient.addColorStop(1,'rgba(255,248,213,0)');
        ctx.fillStyle=gradient;ctx.beginPath();ctx.arc(p.x,p.y,r*4.5,0,Math.PI*2);ctx.fill();
        ctx.fillStyle='rgba(255,252,232,'+alpha+')';ctx.beginPath();ctx.ellipse(p.x,p.y,r*.7,r*1.4,-.15,0,Math.PI*2);ctx.fill();
        if(activeRecord){ctx.strokeStyle='rgba(255,252,232,.65)';ctx.lineWidth=.8;ctx.beginPath();ctx.arc(p.x,p.y,r*2.8,0,Math.PI*2);ctx.stroke();}
        hits.push({row:record[3],x:p.x,y:p.y});
      }
    }
  }
  function render(){
    if(!active)return;
    if(gl&&ready){gl.useProgram(program);gl.uniform2f(uniforms.crop,crop[0],crop[1]);gl.uniform1f(uniforms.clock,elapsed);gl.drawArrays(gl.TRIANGLES,0,6);}
    overlay();
  }
  function tick(now){
    frame=0;
    if(!active||document.hidden||paused){previousTime=0;return;}
    if(now-lastFrame>=32){if(previousTime)elapsed+=Math.min(.08,(now-previousTime)/1000);previousTime=now;lastFrame=now;render();}
    frame=requestAnimationFrame(tick);
  }
  function requestFrame(){if(active&&!paused&&!document.hidden&&!frame)frame=requestAnimationFrame(tick);else render();}
  function stop(){if(frame)cancelAnimationFrame(frame);frame=0;previousTime=0;}
  function hit(event){
    const rect=overlayCanvas.getBoundingClientRect(),x=event.clientX-rect.left,y=event.clientY-rect.top;
    let best=null,distance=18;
    for(const item of hits){const d=Math.hypot(item.x-x,item.y-y);if(d<distance){best=item;distance=d;}}
    return {best,x,y,width};
  }
  overlayCanvas.addEventListener('click',event=>{const p=hit(event);if(p.best)onPick?.(p.best.row);});
  overlayCanvas.addEventListener('pointermove',event=>{const p=hit(event);overlayCanvas.style.cursor=p.best?'pointer':'default';onHover?.(p);});
  overlayCanvas.addEventListener('pointerleave',()=>onHover?.({best:null}));
  document.addEventListener('visibilitychange',()=>{stop();requestFrame();});
  reduced.addEventListener('change',event=>{if(event.matches){paused=true;stop();report();render();}});
  waterCanvas.addEventListener('webglcontextlost',event=>{event.preventDefault();stop();waterCanvas.classList.remove('water-ready');ready=false;report();});
  waterCanvas.addEventListener('webglcontextrestored',()=>{failed=false;initialize();});
  if(image.complete&&image.naturalWidth)initialize();else image.addEventListener('load',initialize,{once:true});
  return {
    setRecords(next,row){records=next;selectedRow=row;render();},
    setActive(next){active=next;if(next){resize();requestFrame();}else stop();},
    togglePause(){paused=!paused;stop();report();requestFrame();return paused;},
    toggleParticles(){showParticles=!showParticles;report();render();return showParticles;},
    resize,
    diagnostics(){return {renderer:gl?'webgl':'photo',ready,failed,paused,active,framesScheduled:!!frame,recordCount:records.length,hitCount:hits.length,elapsed,width,height};}
  };
}
