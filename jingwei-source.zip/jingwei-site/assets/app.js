import {COUNT,scoreText,countText,esc,endpoint,prepare,filterRecords,aggregateWorks,workPairs,histogram,retention,sampleRows,safeState,parseHash,stateHash,csvFor} from './core.js';

const $=id=>document.getElementById(id);
const all=selector=>[...document.querySelectorAll(selector)];
const PAGE_SIZE=12;
let prepared=null,rows=[],selected=null,riverRows=[],riverHits=[],view='home',rankSide=0,rankSort='count',rankLimit=10,matrixMetric='count',matrixSelection=null,toastTimer;
let stored={};try{stored=JSON.parse(localStorage.getItem('jingwei-state-v1')||'{}');}catch{}
let state=safeState(stored);
const initial=parseHash(location.hash);view=initial.view;if(initial.hasState)state=safeState(initial.state);

function toast(message){$('app-toast').textContent=message;$('app-toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('app-toast').hidden=true,3000);}
function persist(){try{localStorage.setItem('jingwei-state-v1',JSON.stringify(state));}catch{}history.replaceState(null,'',stateHash(view,state));}
function go(next){location.hash=stateHash(next,state);}
function selectRow(row,{scroll=false}={}){const found=rows.find(r=>r[3]===row);if(!found)return;selected=found;state.row=row;renderReaders();if(view==='rivers')drawRiver();if(view==='verses')renderResults();persist();if(scroll)$('verse-reader').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});}
function applyFilters({resetPage=true}={}){
  if(!prepared)return;
  if(resetPage)state.page=0;
  rows=filterRecords(prepared,state);
  state.page=Math.min(state.page,Math.max(0,Math.ceil(rows.length/PAGE_SIZE)-1));
  selected=rows.find(r=>r[3]===state.row)||rows[0]||null;state.row=selected?.[3]??null;
  riverRows=sampleRows([...rows].sort((a,b)=>b[2]-a[2]||a[3]-b[3]),72);
  if(selected&&!riverRows.some(r=>r[3]===selected[3]))riverRows.splice(Math.floor(riverRows.length/2),1,selected);
  riverRows.sort((a,b)=>a[3]-b[3]);
  syncControls();renderSummaries();renderReaders();renderView();persist();
}
function syncControls(){
  all('[data-threshold]').forEach(input=>input.value=state.threshold);
  all('[data-score-label]').forEach(output=>output.textContent=scoreText(state.threshold));
  all('[data-search]').forEach(input=>{if(input!==document.activeElement)input.value=state.query;});
  $('lb-work').value=state.lb===null?'':state.lb;$('df-work').value=state.df===null?'':state.df;$('verse-sort').value=state.sort;
}
function renderSummaries(){
  const data=prepared.data;
  const lb=new Set(rows.map(r=>data.lines[0][r[0]][0])),df=new Set(rows.map(r=>data.lines[1][r[1]][0]));
  const html='<span>保留 <strong>'+countText(rows.length)+'</strong> / '+countText(COUNT)+' 组配对</span><span>李白 '+countText(lb.size)+' 部作品</span><span>杜甫 '+countText(df.size)+' 部作品</span>';
  all('[data-summary]').forEach(el=>el.innerHTML=html);
  const chips=[];
  if(state.query)chips.push('<button class="filter-chip" data-clear="query">关键词：'+esc(state.query)+'<span aria-hidden="true">×</span></button>');
  if(state.lb!==null)chips.push('<button class="filter-chip" data-clear="lb">李白：'+esc(data.poems[0][state.lb][0])+'<span aria-hidden="true">×</span></button>');
  if(state.df!==null)chips.push('<button class="filter-chip" data-clear="df">杜甫：'+esc(data.poems[1][state.df][0])+'<span aria-hidden="true">×</span></button>');
  all('[data-chips]').forEach(el=>el.innerHTML=chips.join(''));
}
function readerHtml(record){
  if(!record)return '<div class="empty-state">此处暂未相遇。<small>可降低门槛，或清除作品与关键词筛选。</small></div>';
  const data=prepared.data,a=endpoint(data,record,0),b=endpoint(data,record,1);
  return '<div class="pair-reader"><div class="reader-score"><span>原始相似度</span><strong>'+scoreText(record[2])+'</strong></div>'+[a,b].map((e,i)=>'<div class="reader-side '+(i?'df':'lb')+'"><div class="author">'+(i?'杜甫':'李白')+'</div><blockquote>'+esc(e.text)+'</blockquote><div class="poem-title">《'+esc(e.title)+'》</div></div>').join('')+'<div class="reader-source">原表第 '+record[3]+' 行 · 原始分数 '+record[2]+'<br>原表 H / I：'+esc(a.poemId)+' / '+esc(a.position)+'　J / K：'+esc(b.poemId)+' / '+esc(b.position)+'</div><div class="reader-actions"><button data-copy-row="'+record[3]+'">复制此组链接 ↗</button><button data-read-row="'+record[3]+'">在拾句中阅读 →</button></div></div>';
}
function renderReaders(){
  const html=readerHtml(selected);$('river-reader').innerHTML=html;$('verse-reader').innerHTML=html;
  let nearby=[];
  if(selected){const i=riverRows.findIndex(r=>r[3]===selected[3]);const start=Math.max(0,Math.min(i-2,riverRows.length-6));nearby=riverRows.slice(start,start+6);}
  $('river-keyboard-list').innerHTML=nearby.map(r=>'<button data-select-row="'+r[3]+'" aria-label="选择原表第'+r[3]+'行，相似度'+scoreText(r[2])+'" aria-pressed="'+(selected?.[3]===r[3])+'">'+scoreText(r[2])+'</button>').join('');
}
function initHome(){
  const r=prepared.byRow.get(3527),data=prepared.data,a=endpoint(data,r,0),b=endpoint(data,r,1);
  $('featured-pair').classList.remove('skeleton');$('featured-pair').innerHTML='<div class="featured-side"><span class="author">李白</span><blockquote>'+esc(a.text)+'</blockquote><p>《'+esc(a.title)+'》</p></div><a class="featured-score" href="'+stateHash('verses',{...state,threshold:7000,query:'',lb:null,df:null,row:r[3],page:0})+'" aria-label="阅读这组相似度为'+scoreText(r[2])+'的原句"><small>相似度</small>'+scoreText(r[2])+'</a><div class="featured-side"><span class="author">杜甫</span><blockquote>'+esc(b.text)+'</blockquote><p>《'+esc(b.title)+'》</p></div>';
  const scores=data.records.map(r=>r[2]).sort((a,b)=>a-b),median=(scores[scores.length/2-1]+scores[scores.length/2])/2;
  $('data-stats').innerHTML=[['原始配对',countText(COUNT),'组'],['收录分数中位数',scoreText(median),''],['分数 ≥ 0.8000',countText(retention(data.records,8000)),'组'],['分数 ≥ 0.9000',countText(retention(data.records,9000)),'组']].map(([label,value,unit])=>'<div class="data-stat"><span>'+label+'</span><strong>'+value+'</strong><small>'+unit+'</small></div>').join('');
  for(const side of [0,1]){
    const select=side?$('df-work'):$('lb-work');
    select.innerHTML='<option value="">全部作品</option>'+data.poems[side].map((p,i)=>'<option value="'+i+'">'+esc(p[0])+' · 索引 '+esc(p[1])+'</option>').join('');
  }
}

function curvePoint(w,h,t,side){
  const y=42+t*(h-86),mid=w*.5+Math.sin(t*4)*w*.025;
  const spread=w*.265*Math.pow(Math.max(0,1-t/0.88),1.3);
  return {x:mid+(side?1:-1)*spread,y,mid,spread};
}
function drawRiver(){
  if(view!=='rivers'||!prepared)return;
  const canvas=$('river-canvas'),rect=canvas.getBoundingClientRect();if(!rect.width)return;
  const w=rect.width,h=rect.height,dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);
  const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
  const teal=[39,109,105],gold=[179,140,78],ink='#203e3d';
  const rgba=(rgb,a)=>'rgba('+rgb.join(',')+','+a+')';
  const band=Math.min(48,w*.09);
  for(const side of [0,1]){
    const sign=side?1:-1,points=[];
    for(let i=0;i<=100;i++){const t=i/100,p=curvePoint(w,h,t,side);const mix=Math.min(1,Math.max(0,(t-.72)/.16));points.push({p,outer:p.x+sign*band,inner:p.x-sign*band*(1-mix)});}
    const path=new Path2D();points.forEach(({p,outer},i)=>i?path.lineTo(outer,p.y):path.moveTo(outer,p.y));points.slice().reverse().forEach(({p,inner})=>path.lineTo(inner,p.y));path.closePath();
    const gradient=ctx.createLinearGradient(0,35,0,h-40);gradient.addColorStop(0,rgba(side?gold:teal,.08));gradient.addColorStop(.4,rgba(side?gold:teal,.23));gradient.addColorStop(1,rgba(side?gold:teal,.12));ctx.fillStyle=gradient;ctx.fill(path);
    for(let k=0;k<15;k++){ctx.beginPath();for(let i=0;i<=100;i++){const t=i/100,p=curvePoint(w,h,t,side),offset=((k/14)-.5)*band*1.6*(1-Math.max(0,(t-.7)/.6)),x=p.x+offset+Math.sin(t*23+k)*2;if(!i)ctx.moveTo(x,p.y);else ctx.lineTo(x,p.y);}ctx.strokeStyle=rgba(side?gold:teal,k%3===0?.32:.12);ctx.lineWidth=k%3===0?.8:.5;ctx.stroke();}
  }
  for(let k=0;k<24;k++){
    const t=.08+(k%12)/13*.83,side=k<12?0:1,p=curvePoint(w,h,t,side),sign=side?1:-1,x=p.x+sign*(band+13+(k%3)*4),y=p.y;
    ctx.strokeStyle='rgba(114,133,104,.43)';ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(x,y+8);ctx.quadraticCurveTo(x-3,y-8,x+(k%2?2:-4),y-16);ctx.moveTo(x,y+2);ctx.lineTo(x+6,y-9);ctx.moveTo(x,y);ctx.lineTo(x-6,y-7);ctx.stroke();
    if(k%5===0){ctx.fillStyle='rgba(179,140,78,.26)';ctx.beginPath();ctx.ellipse(x+5,y+10,10,4,.1,0,Math.PI*2);ctx.fill();}
  }
  riverHits=[];
  const ordered=riverRows.slice();
  for(let i=0;i<ordered.length;i++){
    const r=ordered[i],t=ordered.length===1?.38:.06+(i/(ordered.length-1))*.66;
    const a=curvePoint(w,h,t,0),b=curvePoint(w,h,t,1),q=(r[2]-7000)/3000,active=selected?.[3]===r[3],bend=12+((r[3]%7)-3)*2;
    ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.bezierCurveTo(a.mid,a.y+bend,b.mid,b.y+bend,b.x,b.y);ctx.strokeStyle=active?'rgba(163,78,61,.85)':rgba([63,99,87],.07+q*.47);ctx.lineWidth=active?2:0.5+q*1.4;ctx.stroke();
    for(const [p,color]of [[a,teal],[b,gold]]){ctx.beginPath();ctx.arc(p.x,p.y,active?5.5:2.1+q,0,Math.PI*2);ctx.fillStyle=rgba(color,active?1:.38+q*.5);ctx.fill();if(active){ctx.beginPath();ctx.arc(p.x,p.y,9,0,Math.PI*2);ctx.strokeStyle=rgba(color,.22);ctx.lineWidth=1;ctx.stroke();}}
    riverHits.push({row:r[3],a,b,y:a.y});
  }
  ctx.fillStyle=ink;ctx.font='17px "Songti SC",serif';ctx.textAlign='center';ctx.fillText('李 白',w*.235,25);ctx.fillText('杜 甫',w*.765,25);ctx.font='13px "Songti SC",serif';ctx.fillStyle='#74807a';ctx.fillText('历 史 长 河',w*.5,h-11);
  $('river-sample-note').textContent='河面 '+riverRows.length+' 组 / 筛选 '+countText(rows.length)+' 组';$('river-previous').disabled=!selected||riverRows.length<2;$('river-next').disabled=!selected||riverRows.length<2;
}
function hitRiver(event){const rect=$('river-canvas').getBoundingClientRect(),x=event.clientX-rect.left,y=event.clientY-rect.top;let best=null,distance=14;for(const hit of riverHits){const dy=Math.abs(y-hit.y);if(dy<distance&&x>=hit.a.x-12&&x<=hit.b.x+12){best=hit;distance=dy;}}return {best,x,y,width:rect.width};}

function renderWorks(){
  const data=prepared.data,ranking=aggregateWorks(data,rows,rankSide,rankSort);
  $('rank-lb').setAttribute('aria-pressed',String(rankSide===0));$('rank-df').setAttribute('aria-pressed',String(rankSide===1));
  $('work-ranking-list').innerHTML=ranking.slice(0,rankLimit).map((p,i)=>'<button class="rank-item" data-work-side="'+rankSide+'" data-work-index="'+p.index+'" title="'+esc(p.title)+'"><span>'+String(i+1).padStart(2,'0')+'</span><div><strong>'+esc(p.title)+'</strong><small>'+p.count+' 组配对 · 最高 '+scoreText(p.max)+'</small></div></button>').join('')||'<div class="empty-state">暂无作品</div>';
  $('more-works').hidden=ranking.length<=rankLimit;
  const lb=aggregateWorks(data,rows,0).slice(0,10),df=aggregateWorks(data,rows,1).slice(0,10),pairs=workPairs(data,rows);
  if(!lb.length||!df.length){$('work-matrix').innerHTML='<div class="empty-state">当前条件没有作品关系。</div>';$('work-pair-detail').textContent='可降低门槛或清除筛选。';return;}
  const max=Math.max(1,...lb.flatMap(a=>df.map(b=>pairs.get(a.index+':'+b.index)?.[matrixMetric]??0)));
  let grid='<div class="matrix-grid" style="grid-template-columns:110px repeat('+df.length+',minmax(32px,1fr))"><div></div>'+df.map(p=>'<div class="matrix-top" title="'+esc(p.title)+'">'+esc(p.title)+'</div>').join('');
  for(const a of lb){grid+='<div class="matrix-left" title="'+esc(a.title)+'">'+esc(a.title)+'</div>';for(const b of df){const pair=pairs.get(a.index+':'+b.index),v=pair?.[matrixMetric]??0,ratio=pair?(matrixMetric==='max'?(pair.max-7000)/3000:v/max):0;const bg=pair?'rgba(39,109,105,'+(.12+ratio*.76)+')':'rgba(216,223,212,.18)';const text=pair?(matrixMetric==='count'?pair.count:scoreText(pair.max)):'—';grid+='<button class="matrix-cell" style="background:'+bg+';color:'+(ratio>.6?'#faf8f2':'#203e3d')+'" '+(!pair?'disabled':'data-matrix-a="'+a.index+'" data-matrix-b="'+b.index+'"')+' title="'+esc(a.title)+' / '+esc(b.title)+'：'+(pair?(pair.count+' 组，最高 '+scoreText(pair.max)):'当前筛选没有记录')+'" aria-label="'+esc(a.title)+' 与 '+esc(b.title)+'，'+(pair?(pair.count+'组配对，最高相似度'+scoreText(pair.max)):'无收录配对')+'">'+(matrixMetric==='max'&&pair?'·':text)+'</button>';}}
  $('work-matrix').innerHTML=grid+'</div>';
  if(matrixSelection){renderWorkPair(matrixSelection.a,matrixSelection.b);}else $('work-pair-detail').textContent='选择一个格子，查看这两部作品之间的原始配对。';
}
function renderWorkPair(a,b){
  matrixSelection={a,b};const data=prepared.data,matched=rows.filter(r=>data.lines[0][r[0]][0]===a&&data.lines[1][r[1]][0]===b).sort((x,y)=>y[2]-x[2]);
  if(!matched.length){$('work-pair-detail').textContent='这两部作品在当前筛选中没有配对。';return;}
  $('work-pair-detail').innerHTML='<h3>《'+esc(data.poems[0][a][0])+'》 × 《'+esc(data.poems[1][b][0])+'》</h3><p>'+matched.length+' 组配对 · 最高相似度 '+scoreText(matched[0][2])+'</p>'+matched.slice(0,3).map(r=>'<p style="margin-top:12px">'+esc(endpoint(data,r,0).text)+'　／　'+esc(endpoint(data,r,1).text)+'　<span style="color:var(--teal)">'+scoreText(r[2])+'</span></p>').join('')+'<button class="button quiet" data-open-pair-a="'+a+'" data-open-pair-b="'+b+'">查看这两部作品的全部配对 →</button>';
}
function renderResults(){
  const current=rows.slice(state.page*PAGE_SIZE,(state.page+1)*PAGE_SIZE),data=prepared.data;
  $('verse-results').innerHTML=current.map((r,i)=>{const a=endpoint(data,r,0),b=endpoint(data,r,1);return '<article class="verse-result"><span class="row-index">'+String(state.page*PAGE_SIZE+i+1).padStart(2,'0')+'</span><div class="verse-a"><p class="verse-text">'+esc(a.text)+'</p><p class="verse-title">李白《'+esc(a.title)+'》</p></div><div class="verse-b"><p class="verse-text">'+esc(b.text)+'</p><p class="verse-title">杜甫《'+esc(b.title)+'》</p></div><button class="score-button" data-select-row="'+r[3]+'" aria-pressed="'+(selected?.[3]===r[3])+'" aria-label="查看原表第'+r[3]+'行，相似度'+scoreText(r[2])+'">'+scoreText(r[2])+'</button></article>';}).join('')||'<div class="empty-state">此处暂未相遇。<small>试着降低门槛，或清除筛选。</small></div>';
  const pages=Math.ceil(rows.length/PAGE_SIZE);$('page-status').textContent=pages?'第 '+(state.page+1)+' / '+pages+' 页 · '+countText(rows.length)+' 组':'0 组配对';$('page-prev').disabled=state.page===0||!pages;$('page-next').disabled=!pages||state.page>=pages-1;
}

function chartFrame(width,height,inner){return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '+width+' '+height+'" role="img">'+inner+'</svg>';}
function renderDataCharts(){
  if(view!=='data'||!prepared)return;
  const data=prepared.data,records=data.records,bins=histogram(records),W=Math.max(260,$('histogram-chart').clientWidth),H=260,L=43,R=12,T=20,B=37,pw=W-L-R,ph=H-T-B,max=Math.ceil(Math.max(...bins.map(b=>b.count))/2000)*2000;
  let bars='<title>原始配对相似度分布</title><desc>30 个分数区间，宽度 0.01，统计全部 23,448 条配对。</desc>';
  for(let i=0;i<=4;i++){const v=max*i/4,y=T+ph*(1-i/4);bars+='<line class="chart-grid" x1="'+L+'" y1="'+y+'" x2="'+(W-R)+'" y2="'+y+'"/><text class="chart-label" x="'+(L-8)+'" y="'+(y+4)+'" text-anchor="end">'+countText(v)+'</text>';}
  bins.forEach((bin,i)=>{const x=L+i*pw/30+1,y=T+ph*(1-bin.count/max),width=Math.max(1,pw/30-2),label=(bin.lower/10000).toFixed(2)+'—'+((i===29?10000:bin.upper+1)/10000).toFixed(2)+'：'+countText(bin.count)+' 组';bars+='<g class="bar-group" data-bin="'+bin.lower+'" role="button" tabindex="0" aria-label="'+label+'；按区间下限筛选" data-chart-label="'+label+'"><rect class="bar-mark" x="'+x+'" y="'+y+'" width="'+width+'" height="'+Math.max(.7,T+ph-y)+'"/><rect class="bar-hit" x="'+x+'" y="'+T+'" width="'+width+'" height="'+ph+'"/></g>';});
  const ticks=W<400?[0,10,20,30]:[0,5,10,15,20,25,30];for(const i of ticks){const x=L+pw*i/30;bars+='<text class="chart-label" x="'+x+'" y="'+(H-13)+'" text-anchor="middle">'+(.7+i*.01).toFixed(2)+'</text>';}
  bars+='<text class="chart-label" x="'+L+'" y="11">配对数（组）</text>';$('histogram-chart').innerHTML=chartFrame(W,H,bars)+'<div class="chart-tooltip" id="histogram-detail" aria-live="polite">全部 '+countText(COUNT)+' 组原始配对</div>';
  const W2=Math.max(260,$('retention-chart').clientWidth),pw2=W2-L-R,max2=25000,x=s=>L+(s-7000)/3000*pw2,y=n=>T+ph*(1-n/max2),points=Array.from({length:31},(_,i)=>[7000+i*100,retention(records,7000+i*100)]);
  let line='<title>相似度门槛与保留配对数</title><desc>门槛从 0.70 提高到 1.00，保留配对数从 23,448 组减少到 1 组。</desc>';
  for(let i=0;i<=5;i++){const n=i*5000,yy=y(n);line+='<line class="chart-grid" x1="'+L+'" y1="'+yy+'" x2="'+(W2-R)+'" y2="'+yy+'"/><text class="chart-label" x="'+(L-8)+'" y="'+(yy+4)+'" text-anchor="end">'+(n>=10000?n/10000+'万':n)+'</text>';}
  for(const i of ticks)line+='<text class="chart-label" x="'+x(7000+i*100)+'" y="'+(H-13)+'" text-anchor="middle">'+(.7+i*.01).toFixed(2)+'</text>';
  const path=points.map(([s,n],i)=>(i?'L':'M')+x(s)+','+y(n)).join(' '),kept=retention(records,state.threshold),xx=x(state.threshold),yy=y(kept);
  line+='<path d="'+path+'" fill="none" stroke="#276d69" stroke-width="2"/><line x1="'+xx+'" y1="'+T+'" x2="'+xx+'" y2="'+(H-B)+'" stroke="#b38c4e" stroke-width="1" stroke-dasharray="3 4"/><circle cx="'+xx+'" cy="'+yy+'" r="4.5" fill="#b38c4e"/><text class="chart-label" x="'+L+'" y="11">保留配对数（组）</text>';
  $('retention-chart').innerHTML=chartFrame(W2,H,line)+'<div class="chart-tooltip">门槛 '+scoreText(state.threshold)+' · 保留 '+countText(kept)+' 组</div>';
  $('threshold-takeaway').innerHTML='门槛为 '+scoreText(state.threshold)+' 时，<br>留下 <strong>'+countText(kept)+'</strong> 组，占已收录配对的 '+(kept/COUNT*100).toFixed(2)+'%。';
}

function renderView(){if(!prepared)return;if(view==='rivers')requestAnimationFrame(drawRiver);if(view==='works')renderWorks();if(view==='verses')renderResults();if(view==='data')requestAnimationFrame(renderDataCharts);}
function showView(next,{scroll=true}={}){
  view=next;all('[data-view]').forEach(section=>section.hidden=section.dataset.view!==view);all('[data-nav]').forEach(link=>{if(link.dataset.nav===view)link.setAttribute('aria-current','page');else link.removeAttribute('aria-current');});
  const names={home:'才思相融',rivers:'观流',works:'寻脉',verses:'拾句',data:'读数',method:'卷后'};document.title='泾渭分明 · '+names[view];
  if(scroll)window.scrollTo({top:0,behavior:'instant'});renderView();
}
async function load(){
  try{
    $('load-error').hidden=true;
    const response=await fetch(new URL('../data/corpus.json',import.meta.url));if(!response.ok)throw new Error('数据读取失败（'+response.status+'）。');
    prepared=prepare(await response.json());state=safeState(state,prepared.data);if(state.row===null)state.row=3527;
    initHome();applyFilters({resetPage:false});showView(view,{scroll:false});
  }catch(error){$('load-error-message').textContent=error.message+' 请通过网站地址或本地预览打开，避免直接双击文件。';$('load-error').hidden=false;}
}

all('[data-threshold]').forEach(input=>input.addEventListener('input',()=>{state.threshold=Number(input.value);applyFilters();}));
all('[data-search]').forEach(input=>input.addEventListener('input',()=>{state.query=input.value.slice(0,200);applyFilters();}));
all('[data-reset]').forEach(button=>button.addEventListener('click',()=>{state=safeState({threshold:8000,row:3527},prepared?.data);matrixSelection=null;applyFilters();}));
document.addEventListener('click',async event=>{
  const clear=event.target.closest('[data-clear]');if(clear){state[clear.dataset.clear]=clear.dataset.clear==='query'?'':null;applyFilters();return;}
  const rowButton=event.target.closest('[data-select-row]');if(rowButton){selectRow(Number(rowButton.dataset.selectRow));return;}
  const copy=event.target.closest('[data-copy-row]');if(copy){try{await navigator.clipboard.writeText(location.href.split('#')[0]+stateHash('verses',{...state,row:Number(copy.dataset.copyRow)}));toast('这组诗句的链接已复制。');}catch{toast('暂不能访问剪贴板，可复制浏览器地址。');}return;}
  const read=event.target.closest('[data-read-row]');if(read){const i=rows.findIndex(r=>r[3]===Number(read.dataset.readRow));state.page=Math.max(0,Math.floor(i/PAGE_SIZE));go('verses');return;}
  const work=event.target.closest('[data-work-index]');if(work){state[Number(work.dataset.workSide)?'df':'lb']=Number(work.dataset.workIndex);state.page=0;go('verses');return;}
  const cell=event.target.closest('[data-matrix-a]');if(cell){renderWorkPair(Number(cell.dataset.matrixA),Number(cell.dataset.matrixB));return;}
  const openPair=event.target.closest('[data-open-pair-a]');if(openPair){state.lb=Number(openPair.dataset.openPairA);state.df=Number(openPair.dataset.openPairB);state.page=0;go('verses');return;}
  const bin=event.target.closest('[data-bin]');if(bin){state.threshold=Number(bin.dataset.bin);applyFilters();toast('门槛已设为 '+scoreText(state.threshold));return;}
});
document.addEventListener('keydown',event=>{const bin=event.target.closest?.('[data-bin]');if(bin&&(event.key==='Enter'||event.key===' ')){event.preventDefault();bin.dispatchEvent(new MouseEvent('click',{bubbles:true}));}});
$('river-canvas').addEventListener('click',event=>{const hit=hitRiver(event).best;if(hit)selectRow(hit.row);});
$('river-canvas').addEventListener('pointermove',event=>{const {best,x,y,width}=hitRiver(event),note=$('river-float');$('river-canvas').style.cursor=best?'pointer':'default';if(!best){note.hidden=true;return;}const record=prepared.byRow.get(best.row);note.innerHTML=esc(endpoint(prepared.data,record,0).text)+'<br>'+esc(endpoint(prepared.data,record,1).text)+'<br><strong>'+scoreText(record[2])+'</strong>';note.style.left=Math.max(0,Math.min(x+12,width-245))+'px';note.style.top=Math.max(0,y-90)+'px';note.hidden=false;});
$('river-canvas').addEventListener('pointerleave',()=>$('river-float').hidden=true);
for(const [id,direction]of [['river-previous',-1],['river-next',1]])$(id).addEventListener('click',()=>{const i=riverRows.findIndex(r=>r[3]===selected?.[3]);selectRow(riverRows[(i+direction+riverRows.length)%riverRows.length][3]);});
$('rank-lb').addEventListener('click',()=>{rankSide=0;rankLimit=10;renderWorks();});$('rank-df').addEventListener('click',()=>{rankSide=1;rankLimit=10;renderWorks();});
$('rank-sort').addEventListener('change',event=>{rankSort=event.target.value;rankLimit=10;renderWorks();});$('more-works').addEventListener('click',()=>{rankLimit+=15;renderWorks();});$('matrix-metric').addEventListener('change',event=>{matrixMetric=event.target.value;renderWorks();});
for(const [id,key]of [['lb-work','lb'],['df-work','df']])$(id).addEventListener('change',event=>{state[key]=event.target.value===''?null:Number(event.target.value);applyFilters();});
$('verse-sort').addEventListener('change',event=>{state.sort=event.target.value;applyFilters();});
$('page-prev').addEventListener('click',()=>{state.page=Math.max(0,state.page-1);renderResults();persist();});$('page-next').addEventListener('click',()=>{state.page=Math.min(Math.ceil(rows.length/PAGE_SIZE)-1,state.page+1);renderResults();persist();});
$('download-csv').addEventListener('click',()=>{if(!prepared)return;const blob=new Blob([csvFor(prepared.data,rows)],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='泾渭分明_相似度'+scoreText(state.threshold)+'_'+rows.length+'组.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('已导出 '+countText(rows.length)+' 组原始配对。');});
$('histogram-chart').addEventListener('pointerover',event=>{const bin=event.target.closest('[data-chart-label]');if(bin&&$('histogram-detail'))$('histogram-detail').textContent=bin.dataset.chartLabel;});
$('retry-load').addEventListener('click',load);
window.addEventListener('hashchange',()=>{
  if(location.hash==='#home-story'){showView('home',{scroll:false});$('home-story').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});return;}
  if(location.hash==='#main'){document.querySelector('main').focus();return;}
  const next=parseHash(location.hash);showView(next.view);if(next.hasState){state=safeState(next.state,prepared?.data);if(prepared)applyFilters({resetPage:false});}
});
let resizeTimer;new ResizeObserver(()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{drawRiver();renderDataCharts();},80);}).observe(document.querySelector('main'));
showView(view,{scroll:false});load();
