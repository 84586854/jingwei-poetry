# 首页山水

- 最终资源：`assets/river-landscape.webp`，1774 × 887。
- 生成方式：内置图像生成工具。
- 用途：文学主题的艺术意象，不参与相似度计算。

最终提示词：

> A refined Chinese digital-humanities website hero about Li Bai and Du Fu. Contemporary Song-dynasty blue-green landscape scroll, aerial view of two distinct rivers, one muted jade-teal and one mineral ochre-gold, gracefully converging into a broad shared river. Fine ink mountain contours, sparse pines, reeds and wild grasses along the banks, subtle water filaments, delicate mineral pigments on warm ivory xuan paper. Quiet museum exhibition catalogue aesthetic, generous negative space. Wide composition, mountain-river detail in the right two-thirds and lower half; left third pale paper and mist for website typography. Broad S curves, nuanced mixing boundary, smoothly fading edges. No text, calligraphy, seals, watermark, UI or frames. Metaphorical landscape, not a geographic map or quantitative chart.

# 写实观流场景（第二版）

- 最终资源：`assets/river-confluence-real.webp`，1448 × 1086。
- 生成方式：内置图像生成工具。
- 动效：`assets/river-scene.js`，水面纹理平流、反光与泡沫，地形保持静止。
- 图像是虚构汇流场景，非任何具体地点的实拍影像。水上微光对应原始诗句配对，其他景观部分不编码数据。

真实河流参考（仅作为形态与动势参考，未复制这些媒体文件）：

- [Yaroslav Shuraev，河流航拍](https://www.pexels.com/video/aerial-footage-of-water-flowing-in-the-river-8761037/)
- [Efrem Efre，岩石间的急流](https://www.pexels.com/video/aerial-view-of-fast-flowing-river-with-rocks-36125347/)
- [Baker 与 Nef 河流汇合的景观参考](https://www.chile.travel/pt-br/blog/chile-uma-viagem-infinita-a-nova-instalacao-fotografica-que-voce-vera-no-aeroporto/)

最终提示词：

> Use case: photorealistic-natural. Asset type: high resolution natural river-confluence background for an animated immersive website. Create a genuinely photographic, cinematic drone photograph, not an illustration, not a map, no line art, no diagrams. Near top-down aerial camera looking down at a powerful broad river confluence in a lush temperate mountain valley. Landscape frame about 4:3. Exact useful composition: a clear deep turquoise-green river enters from the upper-left edge centered around x=0.22, a natural muted ochre sediment-rich river enters from the upper-right edge around x=0.80. They descend in broad gently curving channels and meet at the center around x=0.53, y=0.43. The joined river continues as one broad winding channel downward toward the lower-center edge around x=0.52, carrying clearly visible turquoise and earthy-gold streaks alongside one another. Real textured water with many tiny current ripples, sun glints, eddies and elongated white foam streaks flowing downstream toward the foreground, strong sense of volume and momentum; clear natural banks with pebble shoals, dark wet stones, lush green reeds and small trees. Dense fine details, credible scale, soft directional late-afternoon daylight, subtle spray at confluence, natural irregular banks, vivid but restrained natural color grading. Ground occupies outer corners and central triangle upstream, river occupies most center and lower half. Water must remain recognizable as moving photographic water, avoid glossy plastic, geometric Y shapes, artificial glowing rivers, cartoon vegetation, symmetry, miniature scale, watercolor, painting, text, labels, numbers, people, buildings, frames, logos or watermarks. The scene is an invented metaphorical confluence, not a specific geographic location.
