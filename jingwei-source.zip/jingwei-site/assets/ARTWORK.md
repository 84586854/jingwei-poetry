# 首页山水

- 最终资源：`assets/river-landscape.webp`，1774 × 887。
- 生成方式：内置图像生成工具。
- 用途：文学主题的艺术意象，不参与相似度计算。

最终提示词：

> A refined Chinese digital-humanities website hero about Li Bai and Du Fu. Contemporary Song-dynasty blue-green landscape scroll, aerial view of two distinct rivers, one muted jade-teal and one mineral ochre-gold, gracefully converging into a broad shared river. Fine ink mountain contours, sparse pines, reeds and wild grasses along the banks, subtle water filaments, delicate mineral pigments on warm ivory xuan paper. Quiet museum exhibition catalogue aesthetic, generous negative space. Wide composition, mountain-river detail in the right two-thirds and lower half; left third pale paper and mist for website typography. Broad S curves, nuanced mixing boundary, smoothly fading edges. No text, calligraphy, seals, watermark, UI or frames. Metaphorical landscape, not a geographic map or quantitative chart.
