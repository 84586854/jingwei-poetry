export const COUNT = 23448;
export const SCORE_MIN = 7000;
export const SCORE_MAX = 10000;
export const scoreText = n => (n / 10000).toFixed(4);
export const countText = n => n.toLocaleString('zh-CN');
export const esc = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function endpoint(data, record, side) {
  const line = data.lines[side][record[side]];
  const poem = data.poems[side][line[0]];
  return {title:poem[0],poemId:poem[1],poemIndex:line[0],text:line[1],position:line[2]};
}
export function prepare(data) {
  if (!Array.isArray(data.records) || data.records.length !== COUNT) throw new Error('数据条数与原表不一致。');
  const rowIds = new Set();
  for (const r of data.records) {
    if (!Number.isInteger(r[2]) || r[2] < SCORE_MIN || r[2] > SCORE_MAX || !Number.isInteger(r[3]) || rowIds.has(r[3])) throw new Error('原始行号或分数校验未通过。');
    rowIds.add(r[3]);
    for (const side of [0,1]) {
      const line = data.lines[side]?.[r[side]];
      if (!line || !data.poems[side]?.[line[0]]) throw new Error('诗句或作品索引不存在。');
    }
  }
  const search = data.records.map(r => [0,1].flatMap(side => {const e=endpoint(data,r,side);return [e.title,e.text];}).join('\n').toLocaleLowerCase());
  return {data,search,byRow:new Map(data.records.map(r=>[r[3],r]))};
}
export function filterRecords(prepared,state,{ignoreWorks=false}={}) {
  const q=state.query.trim().toLocaleLowerCase();
  const rows=prepared.data.records.filter((r,i)=>r[2]>=state.threshold && (!q||prepared.search[i].includes(q)) && (ignoreWorks || ((state.lb===null||prepared.data.lines[0][r[0]][0]===state.lb)&&(state.df===null||prepared.data.lines[1][r[1]][0]===state.df))));
  return rows.sort(state.sort==='source'?(a,b)=>a[3]-b[3]:state.sort==='asc'?(a,b)=>a[2]-b[2]||a[3]-b[3]:(a,b)=>b[2]-a[2]||a[3]-b[3]);
}
export function aggregateWorks(data,rows,side,sort='count') {
  const map=new Map();
  for(const r of rows){const pi=data.lines[side][r[side]][0];const item=map.get(pi)||{index:pi,title:data.poems[side][pi][0],count:0,max:0};item.count++;item.max=Math.max(item.max,r[2]);map.set(pi,item);}
  return [...map.values()].sort(sort==='max'?(a,b)=>b.max-a.max||b.count-a.count||a.index-b.index:(a,b)=>b.count-a.count||b.max-a.max||a.index-b.index);
}
export function workPairs(data,rows){
  const map=new Map();
  for(const r of rows){const a=data.lines[0][r[0]][0],b=data.lines[1][r[1]][0],key=a+':'+b;const item=map.get(key)||{a,b,count:0,max:0,row:r[3]};item.count++;if(r[2]>item.max){item.max=r[2];item.row=r[3];}map.set(key,item);}
  return map;
}
export function histogram(rows){
  const bins=Array.from({length:30},(_,i)=>({lower:7000+i*100,upper:i===29?10000:7099+i*100,count:0}));
  for(const r of rows)bins[Math.min(29,Math.floor((r[2]-7000)/100))].count++;
  return bins;
}
export function retention(rows,threshold){return rows.reduce((n,r)=>n+(r[2]>=threshold),0);}
export function sampleRows(rows,limit=72){if(rows.length<=limit)return rows.slice();return Array.from({length:limit},(_,i)=>rows[Math.round(i*(rows.length-1)/(limit-1))]);}
export function safeState(input={},data=null){
  const bounded=(v,max)=>Number.isInteger(v)&&v>=0&&v<max?v:null;
  return {threshold:Number.isInteger(input.threshold)&&input.threshold>=7000&&input.threshold<=10000?input.threshold:8000,query:typeof input.query==='string'?input.query.slice(0,200):'',lb:bounded(input.lb,data?.poems[0].length??1e6),df:bounded(input.df,data?.poems[1].length??1e6),sort:['asc','desc','source'].includes(input.sort)?input.sort:'desc',row:Number.isInteger(input.row)?input.row:null,page:Number.isInteger(input.page)&&input.page>=0?input.page:0};
}
export function parseHash(hash){
  const [rawView,qs='']=hash.replace(/^#/,'').split('?');const view=['home','rivers','works','verses','data','method'].includes(rawView)?rawView:'home';const params=new URLSearchParams(qs);
  const number=k=>params.has(k)&&/^-?\d+$/.test(params.get(k))?Number(params.get(k)):undefined;
  return {view,hasState:params.has('t')||params.has('q')||params.has('row')||params.has('lb')||params.has('df'),state:{threshold:number('t'),query:params.get('q')??'',lb:number('lb'),df:number('df'),row:number('row'),sort:params.get('sort')??'desc',page:number('page')}};
}
export function stateHash(view,state){const p=new URLSearchParams();p.set('t',state.threshold);if(state.query)p.set('q',state.query);if(state.lb!==null)p.set('lb',state.lb);if(state.df!==null)p.set('df',state.df);if(state.row!==null)p.set('row',state.row);if(state.sort!=='desc')p.set('sort',state.sort);if(state.page)p.set('page',state.page);return '#'+view+'?'+p.toString();}
export function csvFor(data,rows){
  const cell=v=>'"'+String(v).replace(/^[=+\-@\t\r]/,"'$&").replaceAll('"','""')+'"';
  const result=[['原表行号','李白诗题','李白诗句','杜甫诗题','杜甫诗句','相似度原始分数','相似度','原表H列','原表I列','原表J列','原表K列']];
  for(const r of rows){const a=endpoint(data,r,0),b=endpoint(data,r,1);result.push([r[3],a.title,a.text,b.title,b.text,r[2],scoreText(r[2]),a.poemId,a.position,b.poemId,b.position]);}
  return '\uFEFF'+result.map(row=>row.map(cell).join(',')).join('\r\n');
}
